import 'package:flutter/material.dart';
import '../../widgets/data_display/info_card.dart';
import '../../widgets/data_display/stat_card.dart';
import '../../financial_card.dart';
import '../../widgets/common/custom_app_bar.dart';
import 'notifications_screen.dart';

class EnhancedDashboardBossScreen extends StatelessWidget {
  final String userRole;
  
  const EnhancedDashboardBossScreen({super.key, required this.userRole});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: 'Dashboard Boss',
        showBackButton: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const NotificationsScreen()),
              );
            },
          ),
          PopupMenuButton(
            icon: const Icon(Icons.person_outline),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            itemBuilder: (context) => [
              PopupMenuItem(
                child: Row(
                  children: [
                    const Icon(Icons.badge, size: 20, color: Colors.green),
                    const SizedBox(width: 8),
                    Text('Role: $userRole'),
                  ],
                ),
              ),
              const PopupMenuItem(
                child: Row(
                  children: [
                    Icon(Icons.settings, size: 20, color: Colors.grey),
                    SizedBox(width: 8),
                    Text('Settings'),
                  ],
                ),
              ),
              PopupMenuItem(
                child: const Row(
                  children: [
                    Icon(Icons.logout, size: 20, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Logout'),
                  ],
                ),
                onTap: () {
                  Navigator.pushReplacementNamed(context, '/');
                },
              ),
            ],
          ),
        ],
      ),
      backgroundColor: const Color(0xFFF8F9FA),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildTodaysSummary(context),
            const SizedBox(height: 32),
            _buildFinancialOverview(context),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  Widget _buildTodaysSummary(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: const Color(0xFFF3F4F6),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  Icon(Icons.calendar_today_rounded, size: 14, color: const Color(0xFF6B7280)),
                  const SizedBox(width: 6),
                  Text(
                    '${DateTime.now().day} ${_getMonthName(DateTime.now().month)} ${DateTime.now().year}',
                    style: const TextStyle(
                      fontSize: 12,
                      color: Color(0xFF6B7280),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        
        // CARD BESAR: Total Produk dengan Barang Masuk dan Keluar di dalamnya
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color.fromARGB(255, 41, 101, 192), Color.fromARGB(255, 62, 163, 67)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.green.withOpacity(0.2),
                blurRadius: 15,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Bagian Atas: Total Produk
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Total Produk',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '1.200',
                        style: const TextStyle(
                          fontSize: 36,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          letterSpacing: -1,
                        ),
                      ),
                    ],
                  ),
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(
                      Icons.inventory_2_rounded,
                      color: Colors.white,
                      size: 32,
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 24),
              
              // Bagian Bawah: Barang Masuk dan Barang Keluar
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.3), width: 1),
                ),
                child: Row(
                  children: [
                    // Barang Masuk
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Icon(
                                  Icons.arrow_downward_rounded,
                                  color: Color(0xFF4CAF50),
                                  size: 16,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                'Barang Masuk',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white.withOpacity(0.9),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Text(
                            '245',
                            style: const TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Dari minggu lalu',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.white.withOpacity(0.7),
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    // Garis pembatas tengah
                    Container(
                      width: 1,
                      height: 60,
                      color: Colors.white.withOpacity(0.3),
                    ),
                    
                    // Barang Keluar
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Icon(
                                  Icons.arrow_upward_rounded,
                                  color: Color(0xFF66BB6A),
                                  size: 16,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                'Barang Keluar',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white.withOpacity(0.9),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Text(
                            '189',
                            style: const TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Dari minggu lalu',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.white.withOpacity(0.7),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        const SizedBox(height: 20),
        
        // Card Statistik Interaktif
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            children: [
              // Judul Statistik
              Row(
                children: [
                  Icon(
                    Icons.analytics_rounded,
                    color: const Color.fromARGB(255, 16, 89, 185),
                    size: 24,
                  ),
                  const SizedBox(width: 12),
                  Text(
                    'Statistik Produk',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF1A1A1A),
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 24),
              
              // Grid Statistik Interaktif - Row 1: 3 items
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Flexible(
                    flex: 1,
                    child: StatCard(
                      title: 'Sisa Produk',
                      value: '12',
                      icon: Icons.warning_amber_rounded,
                      color: const Color(0xFFF59E0B),
                      onTap: () {
                        _showStatDetailsDialog(context, 'Detail Sisa Produk', _buildStockRendahDetails());
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Flexible(
                    flex: 1,
                    child: StatCard(
                      title: 'Produk Terlaris',
                      value: '3',
                      icon: Icons.star_rounded,
                      color: const Color(0xFFEF4444),
                      onTap: () {
                        _showStatDetailsDialog(context, 'Top 3 Produk Terlaris', _buildProdukTerlarisDetails());
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Flexible(
                    flex: 1,
                    child: StatCard(
                      title: 'Kadaluarsa',
                      value: '1',
                      icon: Icons.event_rounded,
                      color: const Color(0xFF4CAF50),
                      onTap: () {
                        _showStatDetailsDialog(context, 'Produk Kadaluarsa', _buildKadaluarsaDetails());
                      },
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 12),
              
              // Grid Statistik Interaktif - Row 2: 2 items
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Flexible(
                    flex: 1,
                    child: StatCard(
                      title: 'Visualisasi',
                      value: 'Lihat',
                      icon: Icons.bar_chart_rounded,
                      color: const Color(0xFF10B981),
                      onTap: () {
                        _showStatDetailsDialog(context, 'Visualisasi Data Produk', _buildVisualisasiDetails());
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Flexible(
                    flex: 1,
                    child: StatCard(
                      title: 'Pengiriman',
                      value: '3',
                      icon: Icons.local_shipping_rounded,
                      color: const Color(0xFF4CAF50),
                      onTap: () {
                        _showStatDetailsDialog(context, 'Detail Pengiriman', _buildPengirimanDetails());
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        
        const SizedBox(height: 16),
      ],
    );
  }

  // Fungsi untuk menampilkan dialog dengan detail statistik
  void _showStatDetailsDialog(BuildContext context, String title, Widget content) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Container(
            padding: const EdgeInsets.all(24),
            constraints: const BoxConstraints(maxWidth: 600),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF1A1A1A),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: SingleChildScrollView(
                    child: content,
                  ),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF4CAF50),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Tutup',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // Detail untuk Sisa Produk - menggunakan InfoCard
  Widget _buildStockRendahDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Produk dengan Sisa Produk (kurang dari 20 unit):',
          style: TextStyle(fontSize: 14, color: Color(0xFF6B7280)),
        ),
        const SizedBox(height: 12),
        InfoCard(
          title: 'Produk A',
          subtitle: 'Stock: 12 unit',
          icon: Icons.warning_rounded,
          iconColor: const Color(0xFFF59E0B),
          time: 'Segera restock',
        ),
        const SizedBox(height: 8),
        InfoCard(
          title: 'Produk B',
          subtitle: 'Stock: 8 unit',
          icon: Icons.warning_rounded,
          iconColor: const Color(0xFFF59E0B),
          time: 'Segera restock',
        ),
        const SizedBox(height: 8),
        InfoCard(
          title: 'Produk C',
          subtitle: 'Stock: 15 unit',
          icon: Icons.warning_rounded,
          iconColor: const Color(0xFFF59E0B),
          time: 'Prioritas',
        ),
        const SizedBox(height: 8),
        InfoCard(
          title: 'Produk D',
          subtitle: 'Stock: 18 unit',
          icon: Icons.warning_rounded,
          iconColor: const Color(0xFFF59E0B),
          time: 'Prioritas',
        ),
        const SizedBox(height: 12),
        const Text(
          'Total 12 produk memerlukan restock segera.',
          style: TextStyle(fontSize: 12, color: Color(0xFF6B7280), fontStyle: FontStyle.italic),
        ),
      ],
    );
  }

  // Detail untuk Produk Terlaris - menggunakan InfoCard
  Widget _buildProdukTerlarisDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Top 3 produk terlaris bulan ini:',
          style: TextStyle(fontSize: 14, color: Color(0xFF6B7280)),
        ),
        const SizedBox(height: 12),
        InfoCard(
          title: '🏆 Produk X',
          subtitle: 'Terjual: 245 unit',
          icon: Icons.emoji_events,
          iconColor: const Color(0xFFEF4444),
          time: '#1 Terlaris',
        ),
        const SizedBox(height: 8),
        InfoCard(
          title: '🥈 Produk Y',
          subtitle: 'Terjual: 189 unit',
          icon: Icons.emoji_events,
          iconColor: const Color(0xFFEF4444),
          time: '#2 Terlaris',
        ),
        const SizedBox(height: 8),
        InfoCard(
          title: '🥉 Produk Z',
          subtitle: 'Terjual: 156 unit',
          icon: Icons.emoji_events,
          iconColor: const Color(0xFFEF4444),
          time: '#3 Terlaris',
        ),
        const SizedBox(height: 12),
        const Text(
          'Total penjualan bulan ini: 1.200 unit',
          style: TextStyle(fontSize: 12, color: Color(0xFF6B7280), fontStyle: FontStyle.italic),
        ),
      ],
    );
  }

  // Detail untuk Kadaluarsa - menggunakan InfoCard
  Widget _buildKadaluarsaDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Produk yang akan kadaluarsa dalam 30 hari:',
          style: TextStyle(fontSize: 14, color: Color(0xFF6B7280)),
        ),
        const SizedBox(height: 12),
        InfoCard(
          title: 'Produk M',
          subtitle: 'Kadaluarsa: 15 Des 2023',
          icon: Icons.event_rounded,
          iconColor: const Color(0xFF4CAF50),
          time: 'Urgent',
        ),
        const SizedBox(height: 12),
        const Text(
          'Segera lakukan pengecekan dan penjualan prioritas.',
          style: TextStyle(fontSize: 12, color: Color(0xFF6B7280), fontStyle: FontStyle.italic),
        ),
      ],
    );
  }

  // Detail untuk Visualisasi - DIUBAH untuk menampilkan diagram batang dan line
  Widget _buildVisualisasiDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Visualisasi Data Produk',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF1A1A1A)),
        ),
        const SizedBox(height: 20),
        
        // Diagram Batang: Total Produk yang Tersedia di Gudang
        _buildSectionTitle('📊 Total Produk Tersedia di Gudang (Diagram Batang)'),
        const SizedBox(height: 12),
        Container(
          height: 200,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFFF9FAFB),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFE5E7EB)),
          ),
          child: _buildBarChart(),
        ),
        const SizedBox(height: 8),
        _buildChartLegend(),
        
        const SizedBox(height: 24),
        
        // Diagram Line: Total Barang Keluar Berdasarkan Bulan
        _buildSectionTitle('📈 Total Barang Keluar Berdasarkan Bulan (Diagram Line)'),
        const SizedBox(height: 12),
        Container(
          height: 200,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFFF9FAFB),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFE5E7EB)),
          ),
          child: _buildLineChart(),
        ),
        const SizedBox(height: 8),
        _buildLineChartLegend(),
        
        const SizedBox(height: 20),
        
        // Ringkasan Data
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF10B981).withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '📋 Ringkasan Data',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF10B981)),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Total Produk Tersedia',
                          style: TextStyle(fontSize: 12, color: const Color(0xFF6B7280)),
                        ),
                        Text(
                          '1.200 unit',
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF1A1A1A)),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Rata-rata Barang Keluar/Bulan',
                          style: TextStyle(fontSize: 12, color: const Color(0xFF6B7280)),
                        ),
                        Text(
                          '189 unit',
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF1A1A1A)),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  // Widget untuk diagram batang
  Widget _buildBarChart() {
    // Data untuk diagram batang (produk di gudang)
    final List<Map<String, dynamic>> barData = [
      {'product': 'Produk A', 'stock': 450, 'color': const Color(0xFF3B82F6)},
      {'product': 'Produk B', 'stock': 380, 'color': const Color(0xFFEF4444)},
      {'product': 'Produk C', 'stock': 220, 'color': const Color(0xFF10B981)},
      {'product': 'Produk D', 'stock': 150, 'color': const Color(0xFFF59E0B)},
    ];
    
    final double maxStock = 500;
    
    return Column(
      children: [
        // Bar chart
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: barData.map((data) {
              final double heightRatio = data['stock'] / maxStock;
              return Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      margin: const EdgeInsets.symmetric(horizontal: 8),
                      height: 120 * heightRatio,
                      decoration: BoxDecoration(
                        color: data['color'],
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(8),
                        ),
                      ),
                      child: Center(
                        child: Text(
                          '${data['stock']}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      data['product'],
                      style: const TextStyle(fontSize: 10, color: Color(0xFF6B7280)),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'Stok Produk di Gudang',
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: Color(0xFF6B7280)),
        ),
      ],
    );
  }

  // Widget untuk diagram line
  Widget _buildLineChart() {
    // Data untuk diagram line (barang keluar per bulan)
    final List<Map<String, dynamic>> lineData = [
      {'month': 'Jan', 'value': 150},
      {'month': 'Feb', 'value': 180},
      {'month': 'Mar', 'value': 220},
      {'month': 'Apr', 'value': 190},
      {'month': 'Mei', 'value': 210},
      {'month': 'Jun', 'value': 250},
      {'month': 'Jul', 'value': 230},
      {'month': 'Agu', 'value': 200},
      {'month': 'Sep', 'value': 240},
      {'month': 'Okt', 'value': 220},
      {'month': 'Nov', 'value': 260},
      {'month': 'Des', 'value': 280},
    ];
    
    return Column(
      children: [
        // Line chart area
        Expanded(
          child: Stack(
            children: [
              // Grid lines
              Column(
                children: List.generate(4, (index) {
                  return Expanded(
                    child: Container(
                      margin: const EdgeInsets.only(right: 40),
                      decoration: BoxDecoration(
                        border: Border(
                          top: BorderSide(
                            color: const Color(0xFFE5E7EB).withOpacity(0.5),
                            width: 0.5,
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
              
              // Line chart
              Positioned.fill(
                child: Row(
                  children: List.generate(lineData.length, (index) {
                    final bool isLast = index == lineData.length - 1;
                    
                    return Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          // Data point
                          Container(
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(
                              color: const Color(0xFFEF4444),
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 2),
                            ),
                          ),
                          // Line to next point
                          if (!isLast)
                            Expanded(
                              child: Container(
                                width: 1,
                                margin: const EdgeInsets.only(top: 4),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      const Color(0xFFEF4444).withOpacity(0.8),
                                      const Color(0xFFEF4444).withOpacity(0.3),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          const SizedBox(height: 20),
                          Text(
                            lineData[index]['month'],
                            style: const TextStyle(fontSize: 10, color: Color(0xFF6B7280)),
                          ),
                          Text(
                            '${lineData[index]['value']}',
                            style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Color(0xFFEF4444)),
                          ),
                        ],
                      ),
                    );
                  }),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'Barang Keluar Per Bulan (unit)',
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: Color(0xFF6B7280)),
        ),
      ],
    );
  }

  // Widget legend untuk diagram batang
  Widget _buildChartLegend() {
    return Wrap(
      spacing: 16,
      runSpacing: 8,
      children: [
        _buildLegendItem(const Color(0xFF3B82F6), 'Produk A (450 unit)'),
        _buildLegendItem(const Color(0xFFEF4444), 'Produk B (380 unit)'),
        _buildLegendItem(const Color(0xFF10B981), 'Produk C (220 unit)'),
        _buildLegendItem(const Color(0xFFF59E0B), 'Produk D (150 unit)'),
      ],
    );
  }

  // Widget legend untuk diagram line
  Widget _buildLineChartLegend() {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: const Color(0xFFFEF2F2),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: const BoxDecoration(
              color: Color(0xFFEF4444),
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8),
          const Text(
            'Trend Barang Keluar: Meningkat 12% dari tahun lalu',
            style: TextStyle(fontSize: 12, color: Color(0xFFEF4444), fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }

  Widget _buildLegendItem(Color color, String text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          text,
          style: const TextStyle(fontSize: 11, color: Color(0xFF6B7280)),
        ),
      ],
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF1A1A1A)),
    );
  }

  // Detail untuk Pengiriman - DIUBAH untuk menampilkan detail lengkap
  Widget _buildPengirimanDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Detail Pengiriman Aktif',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF1A1A1A)),
        ),
        const SizedBox(height: 20),
        
        // Pengiriman 1
        _buildPengirimanCard(
          nomor: '#001',
          status: 'Dalam Perjalanan',
          statusColor: const Color(0xFF3B82F6),
          toko: 'Toko Maju Jaya',
          alamat: 'Jl. Sudirman No. 123, Jakarta Pusat, DKI Jakarta 10220',
          telepon: '+62 812-3456-7890',
          tanggal: '15 Des 2023',
          items: ['Produk A (50 unit)', 'Produk B (30 unit)'],
          total: '80 unit',
        ),
        
        const SizedBox(height: 16),
        
        // Pengiriman 2
        _buildPengirimanCard(
          nomor: '#002',
          status: 'Siap Dikirim',
          statusColor: const Color(0xFFF59E0B),
          toko: 'Toko Sejahtera Abadi',
          alamat: 'Jl. Thamrin No. 45, Jakarta Selatan, DKI Jakarta 12940',
          telepon: '+62 813-9876-5432',
          tanggal: '16 Des 2023',
          items: ['Produk C (25 unit)', 'Produk D (15 unit)'],
          total: '40 unit',
        ),
        
        const SizedBox(height: 16),
        
        // Pengiriman 3
        _buildPengirimanCard(
          nomor: '#003',
          status: 'Terkirim',
          statusColor: const Color(0xFF10B981),
          toko: 'Toko Makmur Sentosa',
          alamat: 'Jl. Gatot Subroto No. 78, Jakarta Barat, DKI Jakarta 11470',
          telepon: '+62 811-2233-4455',
          tanggal: '14 Des 2023',
          items: ['Produk X (100 unit)'],
          total: '100 unit',
        ),
        
        const SizedBox(height: 20),
        
        // Maps Section
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFFF9FAFB),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFE5E7EB)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.map_rounded, color: Color(0xFFEF4444), size: 20),
                  const SizedBox(width: 8),
                  const Text(
                    'Lokasi Pengiriman',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF1A1A1A)),
                  ),
                  const Spacer(),
                  ElevatedButton.icon(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF10B981),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    ),
                    icon: const Icon(Icons.directions_rounded, size: 16),
                    label: const Text('Buka Maps', style: TextStyle(fontSize: 12)),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              // Simulasi peta sederhana
              Container(
                height: 150,
                decoration: BoxDecoration(
                  color: const Color(0xFFE5E7EB),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.location_on_rounded, color: Color(0xFFEF4444), size: 40),
                      const SizedBox(height: 8),
                      const Text(
                        '3 Lokasi Pengiriman Aktif',
                        style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Color(0xFF6B7280)),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Jakarta Pusat, Jakarta Selatan, Jakarta Barat',
                        style: TextStyle(fontSize: 12, color: const Color(0xFF6B7280).withOpacity(0.8)),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        
        const SizedBox(height: 16),
        
        // Ringkasan Pengiriman
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF4CAF50).withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              const Icon(Icons.local_shipping_rounded, color: Color(0xFF4CAF50), size: 24),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Total Pengiriman Bulan Ini',
                      style: TextStyle(fontSize: 12, color: const Color(0xFF6B7280)),
                    ),
                    Text(
                      '3 Pengiriman • 220 Unit',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF4CAF50)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPengirimanCard({
    required String nomor,
    required String status,
    required Color statusColor,
    required String toko,
    required String alamat,
    required String telepon,
    required String tanggal,
    required List<String> items,
    required String total,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE5E7EB)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Pengiriman $nomor',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF1A1A1A)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: statusColor.withOpacity(0.3)),
                ),
                child: Text(
                  status,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: statusColor,
                  ),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 12),
          
          // Informasi Toko
          Row(
            children: [
              const Icon(Icons.store_rounded, size: 16, color: Color(0xFF6B7280)),
              const SizedBox(width: 8),
              Text(
                toko,
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF1A1A1A)),
              ),
            ],
          ),
          
          const SizedBox(height: 8),
          
          // Alamat
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.location_on_rounded, size: 16, color: Color(0xFF6B7280)),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  alamat,
                  style: const TextStyle(fontSize: 13, color: Color(0xFF6B7280)),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 8),
          
          // Telepon
          Row(
            children: [
              const Icon(Icons.phone_rounded, size: 16, color: Color(0xFF6B7280)),
              const SizedBox(width: 8),
              Text(
                telepon,
                style: const TextStyle(fontSize: 13, color: Color(0xFF6B7280)),
              ),
            ],
          ),
          
          const SizedBox(height: 12),
          
          Divider(color: const Color(0xFFE5E7EB).withOpacity(0.5)),
          
          // Detail Barang
          Row(
            children: [
              const Icon(Icons.inventory_2_rounded, size: 16, color: Color(0xFF6B7280)),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Barang: ${items.join(", ")}',
                      style: const TextStyle(fontSize: 13, color: Color(0xFF6B7280)),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Total: $total • Tanggal: $tanggal',
                      style: const TextStyle(fontSize: 13, color: Color(0xFF6B7280)),
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: const Icon(Icons.directions_rounded, color: Color(0xFF3B82F6)),
                onPressed: () {
                  // Aksi untuk membuka maps
                },
                iconSize: 20,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFinancialOverview(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Performa Tahunan',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
            color: const Color(0xFF1A1A1A),
            letterSpacing: -0.5,
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFF3F4F6)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.02),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header dengan Jumlah Transaksi Bulanan
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Jumlah Transaksi Bulanan',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFF1A1A1A),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Januari - Desember 2024',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: const Color(0xFF6B7280),
                        ),
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF3B82F6).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      '📈 Trend',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: const Color(0xFF3B82F6),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              
              // Konten grafik dengan data transaksi
              Container(
                height: 200,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFFF9FAFB),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        '📈 Grafik Jumlah Transaksi',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF1A1A1A),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Jan: 1,250 transaksi\n'
                        'Feb: 1,380 transaksi\n'
                        'Mar: 1,450 transaksi\n'
                        'Apr: 1,520 transaksi\n'
                        'May: 1,600 transaksi\n'
                        'Jun: 1,680 transaksi',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: const Color(0xFF6B7280),
                          height: 1.6,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Jul: 1,550 transaksi • Aug: 1,620 transaksi\n'
                        'Sep: 1,700 transaksi • Oct: 1,750 transaksi\n'
                        'Nov: 1,800 transaksi • Dec: 1,780 transaksi',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: const Color(0xFF6B7280),
                          height: 1.6,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
  
  String _getMonthName(int month) {
    switch (month) {
      case 1: return 'Januari';
      case 2: return 'Februari';
      case 3: return 'Maret';
      case 4: return 'April';
      case 5: return 'Mei';
      case 6: return 'Juni';
      case 7: return 'Juli';
      case 8: return 'Agustus';
      case 9: return 'September';
      case 10: return 'Oktober';
      case 11: return 'November';
      case 12: return 'Desember';
      default: return '';
    }
  }
}