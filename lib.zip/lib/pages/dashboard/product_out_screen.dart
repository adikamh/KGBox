import 'package:flutter/material.dart';
import '../../widgets/common/custom_app_bar.dart';

class ProductOutScreen extends StatefulWidget {
  final String userRole;

  const ProductOutScreen({super.key, required this.userRole});

  @override
  State<ProductOutScreen> createState() => _ProductOutScreenState();
}

class _ProductOutScreenState extends State<ProductOutScreen> {
  final List<Map<String, dynamic>> _products = [
    {
      'id': 'PRD001',
      'name': 'Produk X',
      'code': 'PX001',
      'stock': 150,
    },
    {
      'id': 'PRD002',
      'name': 'Produk Y',
      'code': 'PY002',
      'stock': 85,
    },
    {
      'id': 'PRD003',
      'name': 'Produk Z',
      'code': 'PZ003',
      'stock': 200,
    },
  ];

  Map<String, dynamic>? _selectedProduct;
  final TextEditingController _quantityController = TextEditingController();
  final TextEditingController _notesController = TextEditingController();

  @override
  void dispose() {
    _quantityController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  void _submitProductOut() {
    if (_selectedProduct == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pilih produk terlebih dahulu')),
      );
      return;
    }

    final quantity = int.tryParse(_quantityController.text) ?? 0;
    if (quantity <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Masukkan jumlah yang valid')),
      );
      return;
    }

    if (quantity > _selectedProduct!['stock']) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Jumlah melebihi stok tersedia')),
      );
      return;
    }

    // Here you would typically save to database
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Produk "${_selectedProduct!['name']}" keluar sebanyak $quantity unit')),
    );

    // Reset form
    setState(() {
      _selectedProduct = null;
      _quantityController.clear();
      _notesController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(
        title: 'Produk Keluar',
        showBackButton: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Pilih Produk',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Card(
              elevation: 2,
              child: DropdownButtonFormField<Map<String, dynamic>>(
                value: _selectedProduct,
                hint: const Text('Pilih produk yang akan dikeluarkan'),
                items: _products.map((product) {
                  return DropdownMenuItem(
                    value: product,
                    child: Text('${product['name']} (Stok: ${product['stock']})'),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedProduct = value;
                  });
                },
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Jumlah Keluar',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Card(
              elevation: 2,
              child: TextField(
                controller: _quantityController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Jumlah',
                  hintText: 'Masukkan jumlah produk keluar',
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Catatan (Opsional)',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Card(
              elevation: 2,
              child: TextField(
                controller: _notesController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Catatan',
                  hintText: 'Tambahkan catatan jika diperlukan',
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
              ),
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _submitProductOut,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text(
                  'Simpan Produk Keluar',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
